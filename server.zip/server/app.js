const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 5000;
const usersFilePath = path.join(__dirname, 'data', 'users.json');
const vacanciesFilePath = path.join(__dirname, 'data', 'vacancies.json');
const responsesFilePath = path.join(__dirname, 'data', 'responses.json'); // Новый путь для хранения откликов
app.use(bodyParser.json());
app.use(cors());

app.get('/', (req, res) => {
    res.send('Hello World!');
});

// Получение всех пользователей
app.get('/api/users', (req, res) => {
    fs.readFile(usersFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Ошибка чтения файла users.json:', err);
            return res.status(500).json({ message: 'Ошибка сервера' });
        }

        const users = JSON.parse(data);
        res.status(200).json(users);
    });
});

// Регистрация нового пользователя
app.post('/api/register', (req, res) => {
    fs.readFile(usersFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Ошибка чтения файла users.json:', err);
            return res.status(500).json({ message: 'Ошибка сервера' });
        }

        const users = JSON.parse(data);
        const emailExists = users.some(user => user.email === req.body.email);

        if (emailExists) {
            return res.status(400).json({ message: 'Email уже используется' });
        }

        const newUserId = users.length > 0 ? users[users.length - 1].id + 1 : 1;
        const newUser = { id: newUserId, ...req.body };

        users.push(newUser);

        fs.writeFile(usersFilePath, JSON.stringify(users, null, 2), (err) => {
            if (err) {
                console.error('Ошибка записи файла users.json:', err);
                return res.status(500).json({ message: 'Ошибка сервера' });
            }

            res.status(201).json({ message: 'Пользователь успешно зарегистрирован', userId: newUserId });
        });
    });
});

// Вход пользователя
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;

    fs.readFile(usersFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Ошибка чтения файла users.json:', err);
            return res.status(500).json({ message: 'Ошибка сервера' });
        }

        const users = JSON.parse(data);
        const user = users.find(user => user.email === email && user.password === password);

        if (!user) {
            return res.status(401).json({ message: 'Неправильный email или пароль' });
        }

        res.status(200).json({
            message: 'Успешный вход',
            userId: user.id,
            userName: user.name // Добавляем имя пользователя
        });
    });
});

// Получение данных пользователя по ID
app.get('/api/users/:id', (req, res) => {
    const userId = parseInt(req.params.id);

    // Проверяем, является ли userId числом и не NaN
    if (isNaN(userId)) {
        console.error('Получен некорректный ID пользователя:', req.params.id);
        return res.status(400).json({ message: 'Некорректный ID пользователя' });
    }

    fs.readFile(usersFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Ошибка чтения файла users.json:', err);
            return res.status(500).json({ message: 'Ошибка сервера' });
        }

        const users = JSON.parse(data);
        const user = users.find(user => user.id === userId);

        if (!user) {
            console.error(`Пользователь с ID ${userId} не найден`);
            return res.status(404).json({ message: 'Пользователь не найден' });
        }

        res.status(200).json(user);
    });
});

// Обновление данных пользователя
app.put('/api/users/:id', (req, res) => {
    const userId = parseInt(req.params.id);
    const { field, value } = req.body;

    fs.readFile(usersFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Ошибка чтения файла users.json:', err);
            return res.status(500).json({ message: 'Ошибка сервера' });
        }

        let users = JSON.parse(data);
        const userIndex = users.findIndex(user => user.id === userId);

        if (userIndex === -1) {
            console.error(`Пользователь с ID ${userId} не найден`);
            return res.status(404).json({ message: 'Пользователь не найден' });
        }

        // Проверка, если поле email и значение уже существует
        if (field === 'email' && users.some(user => user.email === value)) {
            return res.status(400).json({ message: 'Email уже используется' });
        }

        // Обновление данных пользователя
        users[userIndex][field] = value;

        fs.writeFile(usersFilePath, JSON.stringify(users, null, 2), (err) => {
            if (err) {
                console.error('Ошибка записи файла users.json:', err);
                return res.status(500).json({ message: 'Ошибка сервера' });
            }

            res.status(200).json({ message: 'Данные успешно обновлены', user: users[userIndex] });
        });
    });
});

// Получение всех вакансий
app.get('/api/vacancies', (req, res) => {
    fs.readFile(vacanciesFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Ошибка чтения файла vacancies.json:', err);
            return res.status(500).json({ message: 'Ошибка сервера' });
        }

        const vacancies = JSON.parse(data);
        res.status(200).json(vacancies);
    });
});

// Получение вакансии по ID
app.get('/api/vacancies/:id', (req, res) => {
    const vacancyId = parseInt(req.params.id);

    fs.readFile(vacanciesFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Ошибка чтения файла vacancies.json:', err);
            return res.status(500).json({ message: 'Ошибка сервера' });
        }

        const vacancies = JSON.parse(data);
        const vacancy = vacancies.find(vac => vac.id === vacancyId);

        if (!vacancy) {
            return res.status(404).json({ message: 'Вакансия не найдена' });
        }

        fs.readFile(usersFilePath, 'utf8', (err, data) => {
            if (err) {
                console.error('Ошибка чтения файла users.json:', err);
                return res.status(500).json({ message: 'Ошибка сервера' });
            }

            const users = JSON.parse(data);
            const user = users.find(usr => usr.id === vacancy.userid);

            if (!user) {
                return res.status(404).json({ message: 'Пользователь не найден' });
            }

            res.status(200).json({ vacancy, user });
        });
    });
});

// Создание новой вакансии
app.post('/api/vacancies', (req, res) => {
    fs.readFile(vacanciesFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Ошибка чтения файла vacancies.json:', err);
            return res.status(500).json({ message: 'Ошибка сервера' });
        }

        const vacancies = JSON.parse(data);
        const newVacancyId = vacancies.length > 0 ? vacancies[vacancies.length - 1].id + 1 : 1;
        const newVacancy = { id: newVacancyId, ...req.body, date: new Date().toISOString().split('T')[0] }; // Форматирование даты

        vacancies.push(newVacancy);

        fs.writeFile(vacanciesFilePath, JSON.stringify(vacancies, null, 2), (err) => {
            if (err) {
                console.error('Ошибка записи файла vacancies.json:', err);
                return res.status(500).json({ message: 'Ошибка сервера' });
            }

            res.status(201).json({ message: 'Вакансия успешно создана', vacancyId: newVacancyId });
        });
    });
});
app.post('/api/responses', (req, res) => {
    fs.readFile(responsesFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Ошибка чтения файла responses.json:', err);
            return res.status(500).json({ message: 'Ошибка сервера' });
        }

        const responses = JSON.parse(data);
        const newResponseId = responses.length > 0 ? responses[responses.length - 1].id + 1 : 1;
        const newResponse = { id: newResponseId, ...req.body };

        responses.push(newResponse);

        fs.writeFile(responsesFilePath, JSON.stringify(responses, null, 2), (err) => {
            if (err) {
                console.error('Ошибка записи файла responses.json:', err);
                return res.status(500).json({ message: 'Ошибка сервера' });
            }

            res.status(201).json({ message: 'Отклик успешно добавлен', responseId: newResponseId });
        });
    });
});
// Получение всех откликов
app.get('/api/responses', (req, res) => {
    fs.readFile(responsesFilePath, 'utf8', (err, responsesData) => {
        if (err) {
            console.error('Ошибка чтения файла responses.json:', err);
            return res.status(500).json({ message: 'Ошибка сервера' });
        }

        fs.readFile(vacanciesFilePath, 'utf8', (err, vacanciesData) => {
            if (err) {
                console.error('Ошибка чтения файла vacancies.json:', err);
                return res.status(500).json({ message: 'Ошибка сервера' });
            }

            fs.readFile(usersFilePath, 'utf8', (err, usersData) => {
                if (err) {
                    console.error('Ошибка чтения файла users.json:', err);
                    return res.status(500).json({ message: 'Ошибка сервера' });
                }

                const responses = JSON.parse(responsesData);
                const vacancies = JSON.parse(vacanciesData);
                const users = JSON.parse(usersData);

                const detailedResponses = responses.map(response => {
                    const vacancy = vacancies.find(vac => vac.id === parseInt(response.idvacansie));
                    const user = users.find(usr => usr.id === response.idsender);
                    const response = responses.find(responses => responses.id === response.disc);
                    return {
                        ...response,
                        vacancyTitle: vacancy ? vacancy.name : 'Вакансия не найдена',
                        userName: user ? user.name : 'Пользователь не найден',
                        Disc: response ? response.disc : 'Пользователь не найден',
                        userEmail: user ? user.email : 'Email не найден'
                    };
                });

                res.status(200).json(detailedResponses);
            });
        });
    });
});


app.listen(port, () => {
    console.log(`Сервер запущен на http://localhost:${port}`);
});
